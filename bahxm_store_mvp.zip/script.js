function buyNow(product) {
  alert("You selected: " + product + "\nIntegrate payment options like PayPal or Stripe for real orders.");
}

function scrollToProducts() {
  document.getElementById("products").scrollIntoView({ behavior: "smooth" });
}
